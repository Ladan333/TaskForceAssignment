<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <style>
        .basic-grid{
            text-align: center;
            border: solid 1px black;
        }
    </style>
</head>
<body>
<?php
header("Location: TaskForceApp.php");
exit();
?>
</body>
</html>